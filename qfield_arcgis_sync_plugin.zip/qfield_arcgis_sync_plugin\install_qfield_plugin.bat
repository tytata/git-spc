@echo off
REM ============================================================
REM  Đóng gói ArcGIS Sync Plugin cho QField
REM  Co the chay file nay tu bat ky thu muc nao
REM ============================================================

setlocal

REM --- Tu dong xac dinh thu muc goc project (cha cua thu muc chua bat file nay) ---
set "SCRIPT_DIR=%~dp0"
REM SCRIPT_DIR = ...ArcGIS-Sync\qfield_arcgis_sync_plugin\
REM Lay thu muc cha (ArcGIS-Sync\)
for %%I in ("%SCRIPT_DIR:~0,-1%") do set "PROJECT_ROOT=%%~dpI"
REM Bo dau \ cuoi
set "PROJECT_ROOT=%PROJECT_ROOT:~0,-1%"

REM Di chuyen ve thu muc goc de tat ca path tuong doi deu dung
cd /d "%PROJECT_ROOT%"

set PLUGIN_DIR=qfield_arcgis_sync_plugin
set OUT_ZIP=qfield_arcgis_sync_plugin.zip
set ANDROID_ADB_PATH=

echo.
echo ============================================================
echo  ArcGIS Sync Plugin for QField - Packing tool
echo ============================================================
echo.

REM Kiểm tra thư mục plugin tồn tại
if not exist "%PLUGIN_DIR%\main.qml" (
    echo [ERROR] Khong tim thay %PLUGIN_DIR%\main.qml
    echo         Chay file nay tu thu muc goc cua project.
    pause & exit /b 1
)

REM Xóa file zip cũ nếu có
if exist "%OUT_ZIP%" del /f "%OUT_ZIP%"

REM Đóng gói thành zip (dùng PowerShell vì Windows không có zip built-in)
echo [1/3] Dang dong goi %PLUGIN_DIR% thanh %OUT_ZIP%...
powershell -Command "Compress-Archive -Path '%PLUGIN_DIR%' -DestinationPath '%OUT_ZIP%' -Force"

if errorlevel 1 (
    echo [ERROR] Khong the tao file zip. Can co PowerShell.
    pause & exit /b 1
)

echo [OK] Da tao: %OUT_ZIP%
echo.

REM In hướng dẫn cài đặt
echo ============================================================
echo  HUONG DAN CAI PLUGIN VAO QFIELD (Android)
echo ============================================================
echo.
echo  CACH 1 - Qua URL (don gian nhat):
echo  -----------------------------------
echo  1. Host file %OUT_ZIP% len mot URL co the truy cap tu dien thoai
echo     Vi du: Google Drive, Dropbox, server noi bo...
echo  2. Mo QField tren dien thoai
echo  3. Vao Menu (goc tren trai) ^> Plugins
echo  4. Nhan dau "+" hoac "Install from URL"
echo  5. Dan URL cua file zip vao va nhan Install
echo  6. QField tu dong giai nen vao: /sdcard/Android/data/ch.opengis.qfield/files/plugins/
echo  7. Bat plugin: trong danh sach Plugins, tim "ArcGIS Sync" ^> bat ON
echo.
echo  CACH 2 - Copy thu cong qua ADB:
echo  ---------------------------------
echo  1. Ket noi dien thoai Android qua USB (bat USB Debugging)
echo  2. Chay lenh:
echo     adb push %PLUGIN_DIR% /sdcard/Android/data/ch.opengis.qfield/files/plugins/
echo  3. Mo QField ^> Menu ^> Plugins ^> bat "ArcGIS Sync"
echo.
echo  CACH 3 - Copy thu cong qua Windows Explorer:
echo  ----------------------------------------------
echo  1. Ket noi dien thoai qua USB, chon "File Transfer" tren dien thoai
echo  2. Trong Windows Explorer, mo:
echo     Ten_dien_thoai\Internal Storage\Android\data\ch.opengis.qfield\files\plugins\
echo  3. Copy thu muc "%PLUGIN_DIR%" vao day
echo  4. Mo QField ^> Menu ^> Plugins ^> bat "ArcGIS Sync"
echo.
echo ============================================================
echo  CAU HINH SAU KHI CAI:
echo ============================================================
echo  Trong QField sau khi bat plugin, nhan nut [up-arrow] tren toolbar
echo  ^> Dialog "ArcGIS Sync" se hien ra
echo  ^> Nhan "Cai dat" de nhap:
echo     - Service URL: https://gisportal.../FeatureServer
echo     - Token: ArcGIS token cua ban
echo.
echo ============================================================
echo  WORKFLOW:
echo ============================================================
echo  QGIS Desktop:
echo    1. Mo GPKG, chay plugin QGIS "ArcGIS Sync"
echo    2. Nhan "Chuan bi GPKG cho QField" de them _sync_log + triggers
echo    3. Copy GPKG da chuan bi vao QField tren dien thoai
echo.
echo  QField (dien thoai):
echo    4. Mo GPKG trong QField - plugin tu dong ket noi cac layer
echo    5. Them/sua/xoa feature binh thuong trong QField
echo    6. Nhan nut [up-arrow] tren toolbar de xem log
echo    7. Neu co internet: nhan "Submit len ArcGIS" de dong bo ngay
echo    8. Neu khong co internet: log duoc luu trong _sync_log trong GPKG
echo.
echo  QGIS Desktop (sau khi ve):
echo    9. Copy GPKG tu QField ve may tinh
echo   10. Nhan "Import QField Log" trong panel ArcGIS Sync
echo   11. Nhan "Submit" de dong bo len ArcGIS FeatureServer
echo ============================================================
echo.

REM Hỏi có muốn cài qua ADB không
set /p ADB_INSTALL="Ban co muon cai truc tiep qua ADB? (y/n): "
if /i "%ADB_INSTALL%"=="y" (
    echo.
    echo Dang kiem tra ADB...
    where adb >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Khong tim thay ADB trong PATH.
        echo         Tai Android SDK Platform Tools va them vao PATH.
    ) else (
        echo [OK] Tim thay ADB. Dang push plugin...
        adb push "%PLUGIN_DIR%" /sdcard/Android/data/ch.opengis.qfield/files/plugins/
        if errorlevel 1 (
            echo [ERROR] Push that bai. Kiem tra ket noi USB va USB Debugging.
        ) else (
            echo [OK] Da push plugin thanh cong!
            echo      Mo QField ^> Menu ^> Plugins ^> bat "ArcGIS Sync"
        )
    )
)

echo.
echo Hoan tat! File zip: %OUT_ZIP%
pause

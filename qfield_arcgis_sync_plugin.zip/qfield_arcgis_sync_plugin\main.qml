// =============================================================================
// ArcGIS Sync Plugin for QField 4.x
// Version: 1.1.0
//
// Chức năng:
//   1. Theo dõi INSERT / UPDATE / DELETE trên các layer GPKG được cấu hình
//   2. Ghi log vào bảng _sync_log trong cùng file GPKG
//   3. Khi có internet, có thể submit trực tiếp lên ArcGIS FeatureServer
//   4. Hiển thị trạng thái sync qua toolbar button + dialog
//
// Cấu trúc plugin:
//   - iface             : QField plugin interface (context object)
//   - qgisProject       : QgsProject instance (context object)
//   - QfLayerUtils      : utility cho layer operations
//   - QfFeatureUtils    : utility cho feature operations
//   - XMLHttpRequest    : HTTP client (QML built-in)
//
// Cài đặt:
//   Copy thư mục này vào: /sdcard/Android/data/ch.opengis.qfield/files/plugins/
//   Trong QField: Menu → Plugins → bật "ArcGIS Sync"
// =============================================================================

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis

Item {
    id: plugin

    // -------------------------------------------------------------------------
    // Context objects (được QField inject tự động khi plugin load)
    // -------------------------------------------------------------------------
    property var mainWindow: iface.mainWindow()

    // -------------------------------------------------------------------------
    // Cấu hình — đọc từ QML Settings (lưu trên thiết bị)
    // -------------------------------------------------------------------------
    QtObject {
        id: cfg

        // URL gốc ArcGIS FeatureServer (không có trailing slash)
        property string serviceUrl: settings.value("arcgis_sync/service_url", "")

        // Auth Service (tự động lấy + gia hạn token — giống QGIS plugin)
        property string authServiceUrl: settings.value("arcgis_sync/auth_service_url", "")
        property string authApiKey:     settings.value("arcgis_sync/auth_api_key", "")
        property int    authServerId:   parseInt(settings.value("arcgis_sync/auth_server_id", "1")) || 1

        // Manual token — chỉ dùng khi Auth Service không cấu hình hoặc không online
        property string manualToken: settings.value("arcgis_sync/token", "")

        // Bật/tắt auto-submit khi có internet
        property bool autoSubmit: settings.value("arcgis_sync/auto_submit", false)

        // Ánh xạ: tên layer GPKG → ArcGIS FeatureServer layer ID
        // Phải khớp với layer_config.py bên QGIS
        property var layerIdMap: {
            "F01_PB03_ThietBiDongCat_TT":  0,
            "F02_PB03_ThietBiDoDem_TT":    1,
            "F03_PB03_TuBu_TT":            2,
            "F04_PB03_MayBienAp_TT":       3,
            "F05_PB03_TramBienAp_TT":      4,
            "F06_PB03_DiemRanhGioi_TT":    5,
            "F07_PB03_DauNoi_TT":          6,
            "F08_PB03_CotDien_TT":         7,
            "F09_PB03_DuongDay_TT":        8,
            "F10_PB03_NenTram_TT":         9,
            "F11_PB03_MuongCap_TT":       10,
            "F12_PB03_SCADA_TT":          11,
            "F13_PB03_HopNoiCapNgam_TT":  12
        }

        function save() {
            settings.setValue("arcgis_sync/service_url",    serviceUrl)
            settings.setValue("arcgis_sync/auth_service_url", authServiceUrl)
            settings.setValue("arcgis_sync/auth_api_key",   authApiKey)
            settings.setValue("arcgis_sync/auth_server_id", String(authServerId))
            settings.setValue("arcgis_sync/token",          manualToken)
            settings.setValue("arcgis_sync/auto_submit",    autoSubmit)
        }
    }

    // QSettings để lưu cấu hình trên thiết bị
    Settings {
        id: settings
        category: "ArcGISSyncPlugin"
    }

    // -------------------------------------------------------------------------
    // Token Manager — tự động lấy / gia hạn token từ Auth Service
    // -------------------------------------------------------------------------
    QtObject {
        id: tokenMgr

        // Token hiện tại đang dùng (được cập nhật bởi _fetchToken hoặc manual)
        property string currentToken: ""

        // Trạng thái hiển thị trong UI
        // "ok" | "expiring" | "expired" | "error" | "manual" | "none"
        property string status: "none"
        property string statusText: "Chưa có token"
        property string expiresAt: ""  // ISO string, rỗng nếu không biết

        // Fetch token từ Auth Service (XMLHttpRequest, non-blocking)
        // onDone(token) hoặc onFail(errMsg) được gọi khi xong
        function fetch(onDone, onFail) {
            let authUrl = cfg.authServiceUrl.trim()
            let apiKey  = cfg.authApiKey.trim()
            let srvId   = cfg.authServerId

            if (!authUrl || !apiKey) {
                // Không cấu hình Auth Service → dùng manual token
                let manual = cfg.manualToken.trim()
                if (manual) {
                    currentToken = manual
                    status = "manual"
                    statusText = "🔑 Manual token"
                    expiresAt = ""
                    if (onDone) onDone(manual)
                } else {
                    status = "none"
                    statusText = "❌ Chưa cấu hình token"
                    if (onFail) onFail("Chưa cấu hình token. Vào Cài đặt để nhập Auth Service hoặc Manual Token.")
                }
                return
            }

            // Gọi Auth Service: POST /api/v1/tokens/generate
            let url  = authUrl.replace(/\/$/, "") + "/api/v1/tokens/generate"
            let body = JSON.stringify({ server_id: srvId, force_refresh: false })

            let xhr = new XMLHttpRequest()
            xhr.open("POST", url)
            xhr.setRequestHeader("Content-Type", "application/json")
            xhr.setRequestHeader("Accept", "application/json")
            xhr.setRequestHeader("X-API-Key", apiKey)
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== 4) return
                try {
                    let data = JSON.parse(xhr.responseText)
                    if (!data.success) {
                        let msg = data.message || "Auth Service trả lỗi không xác định"
                        _handleFetchError(msg, onFail)
                        return
                    }
                    let tokenData = data.data || {}
                    let tok = tokenData.token || ""
                    if (!tok) {
                        _handleFetchError("Auth Service không trả về token", onFail)
                        return
                    }
                    currentToken = tok
                    expiresAt = tokenData.expires_at || ""
                    status = "ok"
                    statusText = _buildStatusText()
                    _log("Token fetched from Auth Service. Expires: " + expiresAt)
                    if (onDone) onDone(tok)
                } catch(e) {
                    _handleFetchError("Parse error: " + e, onFail)
                }
            }
            xhr.send(body)
        }

        // Force-refresh: PUT /api/v1/tokens/{id}/refresh
        function forceRefresh(onDone, onFail) {
            let authUrl = cfg.authServiceUrl.trim()
            let apiKey  = cfg.authApiKey.trim()
            let srvId   = cfg.authServerId

            if (!authUrl || !apiKey) {
                fetch(onDone, onFail)
                return
            }

            let url = authUrl.replace(/\/$/, "") + "/api/v1/tokens/" + srvId + "/refresh"
            let xhr = new XMLHttpRequest()
            xhr.open("PUT", url)
            xhr.setRequestHeader("Content-Type", "application/json")
            xhr.setRequestHeader("Accept", "application/json")
            xhr.setRequestHeader("X-API-Key", apiKey)
            xhr.onreadystatechange = function() {
                if (xhr.readyState !== 4) return
                try {
                    let data = JSON.parse(xhr.responseText)
                    if (!data.success) {
                        _handleFetchError(data.message || "Refresh thất bại", onFail)
                        return
                    }
                    let tokenData = data.data || {}
                    let tok = tokenData.token || ""
                    if (!tok) { _handleFetchError("Refresh không trả về token", onFail); return }
                    currentToken = tok
                    expiresAt = tokenData.expires_at || ""
                    status = "ok"
                    statusText = _buildStatusText()
                    _log("Token force-refreshed. Expires: " + expiresAt)
                    if (onDone) onDone(tok)
                } catch(e) {
                    _handleFetchError("Parse error: " + e, onFail)
                }
            }
            xhr.send(null)
        }

        // Kiểm tra token có sắp hết hạn không (trong vòng 10 phút)
        function isExpiringSoon() {
            if (!expiresAt) return false
            let expMs = Date.parse(expiresAt)
            if (isNaN(expMs)) return false
            return (expMs - Date.now()) < 10 * 60 * 1000
        }

        function isExpired() {
            if (!expiresAt) return false
            let expMs = Date.parse(expiresAt)
            if (isNaN(expMs)) return false
            return Date.now() >= expMs
        }

        // Lấy token hợp lệ: nếu sắp hết hạn thì tự refresh, nếu không thì dùng cache
        function getToken(onDone, onFail) {
            if (currentToken && !isExpiringSoon() && !isExpired()) {
                if (onDone) onDone(currentToken)
                return
            }
            // Hết hạn hoặc sắp hết hạn → fetch mới
            if (currentToken && isExpiringSoon()) {
                _log("Token sắp hết hạn → auto-refresh...")
                forceRefresh(onDone, onFail)
            } else {
                fetch(onDone, onFail)
            }
        }

        function _handleFetchError(msg, onFail) {
            // Fallback sang manual token nếu có
            let manual = cfg.manualToken.trim()
            if (manual && !isExpired()) {
                currentToken = manual
                status = "manual"
                statusText = "⚠ Auth Service lỗi — dùng Manual Token"
                expiresAt = ""
                _log("Auth Service error: " + msg + " → fallback to manual token")
                if (onFail) onFail(null)  // null = có fallback, không hiện lỗi
            } else {
                status = "error"
                statusText = "❌ " + msg
                _log("Token error: " + msg)
                if (onFail) onFail(msg)
            }
        }

        function _buildStatusText() {
            if (!expiresAt) return "🟢 Token hợp lệ (Auth Service)"
            let expMs = Date.parse(expiresAt)
            if (isNaN(expMs)) return "🟢 Token hợp lệ (Auth Service)"
            let diff = expMs - Date.now()
            if (diff <= 0) return "🔴 Token đã hết hạn"
            let mins = Math.floor(diff / 60000)
            let hrs  = Math.floor(mins / 60)
            let rem  = mins % 60
            let timeStr = hrs > 0 ? (hrs + "h " + rem + "m") : (mins + " phút")
            if (diff < 10 * 60 * 1000) return "🟡 Token sắp hết hạn (" + timeStr + ")"
            return "🟢 Token hợp lệ — còn " + timeStr
        }
    }

    // Timer kiểm tra token mỗi 5 phút → tự refresh nếu sắp hết hạn
    Timer {
        id: tokenRefreshTimer
        interval: 5 * 60 * 1000
        repeat: true
        running: cfg.authServiceUrl !== "" && cfg.authApiKey !== ""
        onTriggered: {
            if (tokenMgr.isExpiringSoon() || tokenMgr.isExpired()) {
                _log("Token timer: token sắp/đã hết hạn → auto-refresh...")
                tokenMgr.forceRefresh(
                    function(tok) { _log("Token timer: refreshed OK") },
                    function(err) { if (err) _log("Token timer refresh error: " + err) }
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    // Danh sách pending log entries (chỉ lưu trong RAM, không phụ thuộc SQLite API)
    // Mỗi entry: {seq, action, layerName, arcgisId, featureId, payload, status, error}
    property var actionLog: []
    property int seqCounter: 0
    property bool isSubmitting: false
    property int pendingCount: 0
    property int errorCount: 0

    // Tập {arcgisId+"_"+featureId} đã submit thành công — tránh log lại
    property var submittedIds: ({})

    // Snapshot layer trước khi edit
    // {layerId: {fid: {attrs...}}}
    property var editingSnapshots: ({})

    // -------------------------------------------------------------------------
    // Khởi động — thêm toolbar button
    // -------------------------------------------------------------------------

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(syncButton)
        _connectAllLayers()
        _log("ArcGIS Sync plugin loaded. Layers connected.")
        _updateBadge()
        // Lấy token ngay lúc khởi động (non-blocking)
        tokenMgr.fetch(
            function(tok) { _log("Token ready: " + tokenMgr.statusText) },
            function(err) { if (err) _log("Token init error: " + err) }
        )
    }

    Component.onDestruction: {
        _disconnectAllLayers()
    }

    // -------------------------------------------------------------------------
    // Toolbar button
    // -------------------------------------------------------------------------

    QfToolButton {
        id: syncButton
        text: "⬆"
        iconColor: QfTheme.toolButtonColor
        bgcolor: pendingCount > 0 ? "#0078d4" : (errorCount > 0 ? "#c62828" : QfTheme.toolButtonBackgroundColor)
        round: true
        onClicked: syncDialog.open()
    }

    // -------------------------------------------------------------------------
    // Main dialog
    // -------------------------------------------------------------------------

    QfDialog {
        id: syncDialog

        x: mainWindow ? (mainWindow.width - width) / 2 : 0
        y: mainWindow ? (mainWindow.height - height) / 2 : 0
        width: Math.min(mainWindow ? mainWindow.width * 0.92 : 400, 480)
        height: Math.min(mainWindow ? mainWindow.height * 0.85 : 600, 640)
        parent: mainWindow ? mainWindow.contentItem : plugin

        title: "ArcGIS Sync"

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 12
            spacing: 8

            // --- Token status ---
            Rectangle {
                Layout.fillWidth: true
                height: 28
                radius: 4
                color: tokenMgr.status === "ok"       ? "#e8f5e9"
                     : tokenMgr.status === "manual"    ? "#fff8e1"
                     : tokenMgr.status === "error"     ? "#fdecea"
                     :                                   "#f7f8fa"

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 6
                    spacing: 6

                    Text {
                        text: tokenMgr.statusText
                        font.pixelSize: 11
                        color: tokenMgr.status === "ok"     ? "#2e7d32"
                             : tokenMgr.status === "manual"  ? "#e65100"
                             : tokenMgr.status === "error"   ? "#c62828"
                             :                                 "#57606a"
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                    }

                    Text {
                        text: "↺"
                        font.pixelSize: 14
                        color: "#0078d4"
                        MouseArea {
                            anchors.fill: parent
                            onClicked: tokenMgr.forceRefresh(
                                function(tok) { iface.displayToast("Token đã được gia hạn.") },
                                function(err) { if (err) iface.displayToast("Lỗi gia hạn token: " + err) }
                            )
                        }
                    }
                }
            }

            // --- Log status bar ---
            Rectangle {
                Layout.fillWidth: true
                height: 32
                radius: 6
                color: pendingCount > 0 ? "#e3f2fd"
                     : errorCount > 0   ? "#fdecea"
                     :                    "#e8f5e9"

                Text {
                    anchors.centerIn: parent
                    text: {
                        if (actionLog.length === 0) return "Không có thay đổi chờ sync"
                        let parts = []
                        if (pendingCount > 0) parts.push(pendingCount + " chờ gửi")
                        if (errorCount > 0)   parts.push(errorCount + " lỗi")
                        let done = actionLog.length - pendingCount - errorCount
                        if (done > 0) parts.push(done + " xong")
                        return parts.join("  |  ")
                    }
                    font.pixelSize: 13
                    font.bold: true
                    color: pendingCount > 0 ? "#0d47a1"
                         : errorCount > 0   ? "#b71c1c"
                         :                    "#1b5e20"
                }
            }

            // --- Log table ---
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                color: "#f7f8fa"
                border.color: "#e5e7eb"
                radius: 4

                ListView {
                    id: logListView
                    anchors.fill: parent
                    anchors.margins: 4
                    clip: true
                    model: actionLog
                    spacing: 2

                    delegate: Rectangle {
                        width: logListView.width
                        height: rowCol.implicitHeight + 10
                        radius: 3
                        color: {
                            let s = modelData.status
                            if (s === "done")    return "#e8f5e9"
                            if (s === "error")   return "#fdecea"
                            if (s === "sending") return "#e3f2fd"
                            return "#ffffff"
                        }
                        border.color: "#e5e7eb"

                        ColumnLayout {
                            id: rowCol
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            anchors.margins: 6
                            spacing: 2

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 6

                                Text {
                                    text: "#" + modelData.seq
                                    font.pixelSize: 10
                                    color: "#57606a"
                                    Layout.minimumWidth: 28
                                }

                                Text {
                                    text: modelData.action.toUpperCase()
                                    font.pixelSize: 12
                                    font.bold: true
                                    color: modelData.action === "insert" ? "#2e7d32"
                                         : modelData.action === "update" ? "#0078d4"
                                         :                                 "#c62828"
                                    Layout.minimumWidth: 52
                                }

                                Text {
                                    text: modelData.layerName.replace("F0", "").replace(/_PB03_/g, " ").replace(/_TT$/, "")
                                    font.pixelSize: 11
                                    color: "#1f2328"
                                    Layout.fillWidth: true
                                    elide: Text.ElideRight
                                }

                                Text {
                                    text: {
                                        let s = modelData.status
                                        if (s === "done")    return "✅"
                                        if (s === "error")   return "❌"
                                        if (s === "sending") return "⏳"
                                        return "⏳"
                                    }
                                    font.pixelSize: 13
                                }
                            }

                            Text {
                                text: "ID: " + modelData.featureId
                                font.pixelSize: 10
                                color: "#57606a"
                                Layout.leftMargin: 34
                                visible: modelData.featureId !== ""
                            }

                            Text {
                                text: modelData.error
                                font.pixelSize: 10
                                color: "#c62828"
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                                Layout.leftMargin: 34
                                visible: modelData.error !== ""
                            }
                        }
                    }

                    Text {
                        anchors.centerIn: parent
                        text: "Danh sách trống\nThực hiện edit trên layer để ghi log"
                        horizontalAlignment: Text.AlignHCenter
                        color: "#aaaaaa"
                        font.pixelSize: 13
                        visible: logListView.count === 0
                    }
                }
            }

            // --- Submit button ---
            Button {
                id: submitBtn
                Layout.fillWidth: true
                text: isSubmitting ? "⏳ Đang gửi…"
                    : (pendingCount + errorCount) > 0 ? "⬆  Submit lên ArcGIS (" + (pendingCount + errorCount) + ")"
                    : "✅ Đã đồng bộ hết"
                enabled: (pendingCount + errorCount) > 0 && !isSubmitting && cfg.serviceUrl !== ""
                         && (tokenMgr.currentToken !== "" || cfg.manualToken !== "")
                onClicked: _doSubmit()

                background: Rectangle {
                    radius: 6
                    color: submitBtn.enabled ? "#0078d4"
                         : submitBtn.hovered ? "#005a9e"
                         :                     "#cccccc"
                    Behavior on color { ColorAnimation { duration: 150 } }
                }

                contentItem: Text {
                    text: submitBtn.text
                    font.pixelSize: 14
                    font.bold: true
                    color: submitBtn.enabled ? "white" : "#888888"
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }

            // --- Xóa log đã done ---
            Button {
                Layout.fillWidth: true
                text: "🗑  Xóa log đã hoàn thành"
                enabled: actionLog.some(e => e.status === "done")
                onClicked: {
                    let newLog = actionLog.filter(e => e.status !== "done")
                    actionLog = newLog
                    _updateBadge()
                }
                background: Rectangle {
                    radius: 6
                    color: parent.enabled ? "#e0e0e0" : "#f0f0f0"
                }
                contentItem: Text {
                    text: parent.text
                    font.pixelSize: 12
                    color: parent.enabled ? "#1f2328" : "#aaaaaa"
                    horizontalAlignment: Text.AlignHCenter
                }
            }

            // --- Cài đặt ---
            Button {
                Layout.fillWidth: true
                text: "⚙  Cài đặt"
                onClicked: {
                    syncDialog.close()
                    settingsDialog.open()
                }
                background: Rectangle { radius: 6; color: "#e0e0e0" }
                contentItem: Text {
                    text: parent.text; font.pixelSize: 12
                    color: "#1f2328"
                    horizontalAlignment: Text.AlignHCenter
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Settings dialog
    // -------------------------------------------------------------------------

    QfDialog {
        id: settingsDialog
        x: mainWindow ? (mainWindow.width - width) / 2 : 0
        y: mainWindow ? (mainWindow.height - height) / 2 : 0
        width: Math.min(mainWindow ? mainWindow.width * 0.92 : 400, 460)
        height: Math.min(mainWindow ? mainWindow.height * 0.92 : 700, 680)
        parent: mainWindow ? mainWindow.contentItem : plugin
        title: "Cài đặt ArcGIS Sync"

        ScrollView {
            anchors.fill: parent
            contentWidth: availableWidth
            clip: true

            ColumnLayout {
                width: parent.width
                anchors.margins: 12
                spacing: 8

                // ── Service URL ─────────────────────────────────────────
                Text { text: "Service URL (FeatureServer):"; font.pixelSize: 13; font.bold: true; color: "#1f2328"; Layout.topMargin: 8 }

                TextField {
                    id: urlField
                    Layout.fillWidth: true
                    text: cfg.serviceUrl
                    placeholderText: "https://gisportal.../FeatureServer"
                    font.pixelSize: 12
                    wrapMode: TextInput.WrapAnywhere
                }

                // ── Auth Service (tự động gia hạn token) ────────────────
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: "#e5e7eb"
                    Layout.topMargin: 4
                    Layout.bottomMargin: 4
                }

                Text {
                    text: "🤖  Auth Service (Token tự động)"
                    font.pixelSize: 13; font.bold: true; color: "#1f2328"
                }

                Text {
                    text: "Plugin tự gọi Auth Service để lấy + gia hạn token.\nKhi token sắp hết hạn (< 10 phút), plugin tự refresh không cần làm gì."
                    font.pixelSize: 11; color: "#57606a"; wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }

                TextField {
                    id: authUrlField
                    Layout.fillWidth: true
                    text: cfg.authServiceUrl
                    placeholderText: "http://localhost:8000"
                    font.pixelSize: 12
                }

                Text { text: "API Key:"; font.pixelSize: 12; color: "#1f2328" }

                TextField {
                    id: authApiKeyField
                    Layout.fillWidth: true
                    text: cfg.authApiKey
                    placeholderText: "X-API-Key của Auth Service…"
                    font.pixelSize: 12
                    echoMode: TextInput.Password
                }

                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "Server ID:"; font.pixelSize: 12; color: "#1f2328"; Layout.minimumWidth: 70 }
                    TextField {
                        id: authServerIdField
                        Layout.fillWidth: true
                        text: String(cfg.authServerId)
                        placeholderText: "1"
                        font.pixelSize: 12
                        inputMethodHints: Qt.ImhDigitsOnly
                    }
                }

                // Nút kiểm tra kết nối Auth Service
                Button {
                    Layout.fillWidth: true
                    text: "🔌  Kiểm tra Auth Service"
                    onClicked: {
                        testResultText.text = "⏳ Đang kiểm tra…"
                        testResultText.color = "#0078d4"
                        let url = authUrlField.text.trim().replace(/\/$/, "") + "/api/v1/tokens/generate"
                        let body = JSON.stringify({
                            server_id: parseInt(authServerIdField.text) || 1,
                            force_refresh: false
                        })
                        let xhr = new XMLHttpRequest()
                        xhr.open("POST", url)
                        xhr.setRequestHeader("Content-Type", "application/json")
                        xhr.setRequestHeader("X-API-Key", authApiKeyField.text.trim())
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState !== 4) return
                            try {
                                let d = JSON.parse(xhr.responseText)
                                if (d.success) {
                                    let exp = (d.data || {}).expires_at || "?"
                                    testResultText.text = "✅ Thành công! Hết hạn: " + exp
                                    testResultText.color = "#2e7d32"
                                } else {
                                    testResultText.text = "❌ " + (d.message || "Lỗi không xác định")
                                    testResultText.color = "#c62828"
                                }
                            } catch(e) {
                                testResultText.text = "❌ Lỗi kết nối"
                                testResultText.color = "#c62828"
                            }
                        }
                        xhr.send(body)
                    }
                    background: Rectangle { radius: 4; color: "#e0e0e0" }
                    contentItem: Text {
                        text: parent.text; font.pixelSize: 12
                        color: "#1f2328"; horizontalAlignment: Text.AlignHCenter
                    }
                }

                Text {
                    id: testResultText
                    text: ""
                    font.pixelSize: 11; wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                    visible: text !== ""
                }

                // ── Manual Token (dự phòng) ──────────────────────────────
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: "#e5e7eb"
                    Layout.topMargin: 4
                    Layout.bottomMargin: 4
                }

                Text {
                    text: "✍  Manual Token (Dự phòng)"
                    font.pixelSize: 13; font.bold: true; color: "#1f2328"
                }

                Text {
                    text: "Chỉ dùng khi Auth Service không cấu hình hoặc offline.\nKhi Auth Service hoạt động, ô này có thể để trống."
                    font.pixelSize: 11; color: "#57606a"; wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }

                TextField {
                    id: manualTokenField
                    Layout.fillWidth: true
                    text: cfg.manualToken
                    placeholderText: "Dán ArcGIS token thủ công vào đây (tùy chọn)…"
                    font.pixelSize: 12
                    echoMode: TextInput.Password
                }

                // ── Options ─────────────────────────────────────────────
                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: "#e5e7eb"
                    Layout.topMargin: 4
                    Layout.bottomMargin: 4
                }

                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "Tự động submit khi online:"; font.pixelSize: 13; Layout.fillWidth: true; color: "#1f2328" }
                    Switch {
                        id: autoSubmitSwitch
                        checked: cfg.autoSubmit
                    }
                }

                // ── Lưu ────────────────────────────────────────────────
                Button {
                    Layout.fillWidth: true
                    Layout.topMargin: 8
                    Layout.bottomMargin: 12
                    text: "💾  Lưu cài đặt"
                    onClicked: {
                        cfg.serviceUrl    = urlField.text.trim()
                        cfg.authServiceUrl = authUrlField.text.trim()
                        cfg.authApiKey    = authApiKeyField.text.trim()
                        cfg.authServerId  = parseInt(authServerIdField.text) || 1
                        cfg.manualToken   = manualTokenField.text.trim()
                        cfg.autoSubmit    = autoSubmitSwitch.checked
                        cfg.save()
                        // Reset token cache → lấy lại với cấu hình mới
                        tokenMgr.currentToken = ""
                        tokenMgr.expiresAt = ""
                        tokenMgr.status = "none"
                        tokenMgr.statusText = "Đang lấy token…"
                        tokenMgr.fetch(
                            function(tok) { iface.displayToast("Token ready: " + tokenMgr.statusText) },
                            function(err) { if (err) iface.displayToast("⚠ " + err) }
                        )
                        settingsDialog.close()
                        syncDialog.open()
                    }
                    background: Rectangle { radius: 6; color: "#0078d4" }
                    contentItem: Text {
                        text: parent.text; font.pixelSize: 13; font.bold: true
                        color: "white"; horizontalAlignment: Text.AlignHCenter
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Layer connection
    // -------------------------------------------------------------------------

    // Lưu handlers để disconnect được
    property var layerHandlers: ({})

    function _connectAllLayers() {
        let layers = QfProjectUtils.mapLayers(qgisProject)
        for (let layerId in layers) {
            _connectLayer(layers[layerId])
        }
    }

    function _disconnectAllLayers() {
        let layers = QfProjectUtils.mapLayers(qgisProject)
        for (let layerId in layers) {
            _disconnectLayer(layers[layerId])
        }
    }

    function _connectLayer(layer) {
        if (!layer) return
        let name = layer.name
        if (!(name in cfg.layerIdMap)) return

        let lid = layer.id

        // Snapshot toàn bộ feature lúc editingStarted
        layer.editingStarted.connect(function() { _onEditingStarted(layer) })
        layer.beforeCommitChanges.connect(function() { _onBeforeCommit(layer) })
        layer.committedFeaturesAdded.connect(function(id, feats) { _onAdded(layer, feats) })
        layer.committedAttributeValuesChanges.connect(function(id, changes) { _onAttrChanged(layer, changes) })
        layer.committedGeometriesChanges.connect(function(id, changes) { _onGeomChanged(layer, changes) })
        layer.committedFeaturesRemoved.connect(function(id, fids) { _onRemoved(layer, fids) })

        _log("Connected: " + name + " (arcgisId=" + cfg.layerIdMap[name] + ")")
    }

    function _disconnectLayer(layer) {
        // QML signal disconnect không cần lưu handler reference nếu dùng anonymous — QField tự cleanup
    }

    // -------------------------------------------------------------------------
    // Change tracking
    // -------------------------------------------------------------------------

    function _onEditingStarted(layer) {
        let lid = layer.id
        let snap = {}
        let it = QfLayerUtils.createFeatureIterator(layer)
        while (it.hasNext()) {
            let feat = it.next()
            snap[feat.id] = _featureToAttrs(layer, feat)
        }
        editingSnapshots[lid] = snap
        let newSnaps = editingSnapshots
        editingSnapshots = newSnaps  // trigger binding refresh
    }

    function _onBeforeCommit(layer) {
        // Snapshot đã được lưu trong editingSnapshots — không cần làm gì thêm
    }

    function _onAdded(layer, features) {
        let layerName = layer.name
        let arcgisId = cfg.layerIdMap[layerName]
        if (arcgisId === undefined) return

        let fieldNames = []
        for (let i = 0; i < layer.fields.count; i++) {
            fieldNames.push(layer.fields.at(i).name)
        }
        let hasId = fieldNames.indexOf("ID") >= 0

        for (let fi = 0; fi < features.length; fi++) {
            let feat = features[fi]
            let idVal = hasId ? feat.attribute("ID") : null
            let idIsNull = (idVal === null || idVal === undefined || idVal === "")
            let featureId = (!idIsNull) ? String(idVal) : "fid:" + feat.id

            let key = arcgisId + "_" + featureId
            if (key in submittedIds) continue

            let payload = _featureToArcGIS(layer, feat, false)
            let entry = _appendAction("insert", layerName, arcgisId, featureId, payload)

            if (idIsNull) {
                entry.status = "error"
                entry.error = "Feature chưa có field ID. Điền giá trị ID → Save lại."
            }
        }

        _updateBadge()
        _maybeAutoSubmit()
    }

    function _onAttrChanged(layer, changes) {
        _registerUpdates(layer, Object.keys(changes).map(Number))
    }

    function _onGeomChanged(layer, changes) {
        _registerUpdates(layer, Object.keys(changes).map(Number))
    }

    function _onRemoved(layer, fids) {
        let layerName = layer.name
        let arcgisId = cfg.layerIdMap[layerName]
        if (arcgisId === undefined) return

        let lid = layer.id
        let editSnap = editingSnapshots[lid] || {}

        for (let fi = 0; fi < fids.length; fi++) {
            let fid = fids[fi]
            let snap = editSnap[fid]
            if (!snap) {
                _appendAction("delete", layerName, arcgisId, "fid:" + fid, {objectid: fid})
                continue
            }
            let idVal = snap["ID"]
            if (!idVal) continue
            let idStr = String(idVal)

            // Nếu đang pending insert → cancel
            let pendingInsertIdx = actionLog.findIndex(e =>
                e.action === "insert" && e.arcgisId === arcgisId &&
                e.featureId === idStr && e.status === "pending")
            if (pendingInsertIdx >= 0) {
                let newLog = actionLog.filter((_, i) => i !== pendingInsertIdx)
                actionLog = newLog
            } else {
                _appendAction("delete", layerName, arcgisId, idStr, {id_val: idStr, objectid: null})
            }
        }

        _updateBadge()
    }

    function _registerUpdates(layer, fids) {
        let layerName = layer.name
        let arcgisId = cfg.layerIdMap[layerName]
        if (arcgisId === undefined) return

        let existingOids = new Set(actionLog
            .filter(e => e.action === "update" && e.arcgisId === arcgisId && e.status === "pending")
            .map(e => e.payload && e.payload.attributes ? e.payload.attributes["OBJECTID"] : null)
            .filter(v => v !== null))

        for (let fi = 0; fi < fids.length; fi++) {
            let fid = fids[fi]
            let feat = layer.getFeature(fid)
            if (!feat || !feat.valid) continue
            let oid = feat.attribute("OBJECTID")
            if (existingOids.has(oid)) continue
            let payload = _featureToArcGIS(layer, feat, true)
            let fieldNames = []
            for (let i = 0; i < layer.fields.count; i++) fieldNames.push(layer.fields.at(i).name)
            let hasId = fieldNames.indexOf("ID") >= 0
            let featureId = hasId ? String(feat.attribute("ID")) : "OID:" + oid
            _appendAction("update", layerName, arcgisId, featureId, payload)
            existingOids.add(oid)
        }

        _updateBadge()
    }

    // -------------------------------------------------------------------------
    // Feature serialization
    // -------------------------------------------------------------------------

    function _featureToAttrs(layer, feat) {
        let attrs = {}
        for (let i = 0; i < layer.fields.count; i++) {
            let name = layer.fields.at(i).name
            attrs[name] = feat.attribute(name)
        }
        return attrs
    }

    function _featureToArcGIS(layer, feat, includeObjectId) {
        let attributes = {}
        for (let i = 0; i < layer.fields.count; i++) {
            let fname = layer.fields.at(i).name
            let val = feat.attribute(fname)
            if (val === undefined || val === null || (typeof val === "object" && val !== null && val.isNull)) {
                attributes[fname] = null
            } else {
                attributes[fname] = val
            }
        }

        if (!includeObjectId) {
            delete attributes["OBJECTID"]
        }

        // Geometry → ArcGIS format (Web Mercator EPSG:3857)
        let geomDict = null
        let geom = feat.geometry
        if (geom && !geom.isEmpty()) {
            // QField geometry thường đã ở CRS của layer
            // Cần reproject sang EPSG:3857 nếu layer dùng CRS khác
            let wkt = geom.asWkt(8)
            geomDict = _wktToArcGIS(wkt)
        }

        let rec = { attributes: attributes }
        if (geomDict) rec["geometry"] = geomDict
        return rec
    }

    function _wktToArcGIS(wkt) {
        // Phân tích WKT cơ bản — hỗ trợ Point, LineString, Polygon + Multi variants
        let sr = { wkid: 102100, latestWkid: 3857 }

        if (wkt.startsWith("Point") || wkt.startsWith("POINT")) {
            let coords = wkt.replace(/^POINT\s*\(\s*/, "").replace(/\s*\)$/, "").trim()
            let parts = coords.split(/\s+/)
            if (parts.length >= 2) {
                return { x: parseFloat(parts[0]), y: parseFloat(parts[1]), spatialReference: sr }
            }
        }

        if (wkt.startsWith("LineString") || wkt.startsWith("LINESTRING") ||
            wkt.startsWith("MultiLineString") || wkt.startsWith("MULTILINESTRING")) {
            return { paths: _extractRings(wkt, false), spatialReference: sr }
        }

        if (wkt.startsWith("Polygon") || wkt.startsWith("POLYGON") ||
            wkt.startsWith("MultiPolygon") || wkt.startsWith("MULTIPOLYGON")) {
            return { rings: _extractRings(wkt, true), spatialReference: sr }
        }

        return null
    }

    function _extractRings(wkt, isPolygon) {
        let rings = []
        let matches = wkt.match(/\(([^()]+)\)/g) || []
        for (let m of matches) {
            let inner = m.replace(/^\(/, "").replace(/\)$/, "").trim()
            let points = inner.split(",").map(p => {
                let parts = p.trim().split(/\s+/)
                return [parseFloat(parts[0]), parseFloat(parts[1])]
            })
            rings.push(points)
        }
        return rings
    }

    // -------------------------------------------------------------------------
    // Action log
    // -------------------------------------------------------------------------

    function _appendAction(action, layerName, arcgisId, featureId, payload) {
        seqCounter++
        let entry = {
            seq: seqCounter,
            action: action,
            layerName: layerName,
            arcgisId: arcgisId,
            featureId: featureId,
            payload: payload,
            status: "pending",
            error: ""
        }
        let newLog = actionLog.concat([entry])
        actionLog = newLog
        _log("[ActionLog #" + seqCounter + "] " + action.toUpperCase() + " [" + layerName + "] ID=" + featureId)
        return entry
    }

    function _updateBadge() {
        pendingCount = actionLog.filter(e => e.status === "pending").length
        errorCount   = actionLog.filter(e => e.status === "error").length
    }

    // -------------------------------------------------------------------------
    // Submit lên ArcGIS FeatureServer
    // -------------------------------------------------------------------------

    function _doSubmit() {
        if (isSubmitting) return
        let pending = actionLog.filter(e => e.status === "pending" || e.status === "error")
        if (pending.length === 0) return
        if (!cfg.serviceUrl) {
            iface.displayToast("Chưa cấu hình Service URL. Vào Cài đặt để nhập.")
            return
        }
        isSubmitting = true
        // Lấy token hợp lệ trước khi gửi — tự refresh nếu sắp hết hạn
        tokenMgr.getToken(
            function(tok) {
                _log("Submit started (token: " + tokenMgr.status + ")")
                _submitNext()
            },
            function(err) {
                isSubmitting = false
                iface.displayToast("Không lấy được token: " + (err || "Vào Cài đặt → Auth Service"))
            }
        )
    }

    function _submitNext() {
        let idx = actionLog.findIndex(e => e.status === "pending" || e.status === "error")
        if (idx < 0) {
            isSubmitting = false
            _updateBadge()
            let doneCount = actionLog.filter(e => e.status === "done").length
            iface.displayToast("✅ Submit xong " + doneCount + " thao tác.")
            return
        }
        _submitEntryAt(idx)
    }

    function _submitEntryAt(idx) {
        let entry = actionLog[idx]

        // Cập nhật status thành sending
        let newLog = actionLog.map((e, i) => i === idx ? Object.assign({}, e, {status: "sending"}) : e)
        actionLog = newLog
        _updateBadge()

        let action = entry.action
        let arcgisId = entry.arcgisId
        let payload = entry.payload
        let baseUrl = cfg.serviceUrl.replace(/\/$/, "")

        if (action === "insert") {
            // Kiểm tra ID đã tồn tại chưa
            let idVal = payload.attributes ? payload.attributes["ID"] : null
            if (idVal !== null && idVal !== undefined) {
                _queryByIds(arcgisId, [String(idVal)], function(found) {
                    let serverOid = found[String(idVal)]
                    if (serverOid !== undefined) {
                        _markError(idx, "ID '" + idVal + "' đã tồn tại trên server (OID=" + serverOid + ")")
                        _submitNext()
                    } else {
                        _doAdd(idx, arcgisId, payload)
                    }
                }, function(err) {
                    _markError(idx, "Query lỗi: " + err)
                    _submitNext()
                })
            } else {
                _doAdd(idx, arcgisId, payload)
            }

        } else if (action === "update") {
            let idVal = payload.attributes ? payload.attributes["ID"] : null
            if (!idVal) {
                _markError(idx, "UPDATE thiếu field ID")
                _submitNext()
                return
            }
            _queryByIds(arcgisId, [String(idVal)], function(found) {
                let serverOid = found[String(idVal)]
                if (serverOid === undefined) {
                    _markError(idx, "ID '" + idVal + "' không tìm thấy trên server")
                    _submitNext()
                } else {
                    let newPayload = Object.assign({}, payload)
                    newPayload.attributes = Object.assign({}, payload.attributes, {OBJECTID: serverOid})
                    _doUpdate(idx, arcgisId, newPayload)
                }
            }, function(err) {
                _markError(idx, "Query lỗi: " + err)
                _submitNext()
            })

        } else if (action === "delete") {
            let idVal = payload.id_val
            if (!idVal) {
                let oid = payload.objectid
                if (oid) { _doDelete(idx, arcgisId, oid) }
                else { _markError(idx, "DELETE thiếu ID và OBJECTID") ; _submitNext() }
                return
            }
            _queryByIds(arcgisId, [String(idVal)], function(found) {
                let serverOid = found[String(idVal)]
                if (serverOid === undefined) {
                    _markError(idx, "ID '" + idVal + "' không tìm thấy trên server")
                    _submitNext()
                } else {
                    _doDelete(idx, arcgisId, serverOid)
                }
            }, function(err) {
                _markError(idx, "Query lỗi: " + err)
                _submitNext()
            })
        }
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    function _queryByIds(arcgisId, idValues, onDone, onError) {
        let joined = idValues.map(v => "'" + v + "'").join(",")
        let where = "ID IN (" + joined + ")"
        let url = cfg.serviceUrl.replace(/\/$/, "") + "/" + arcgisId +
            "/query?where=" + encodeURIComponent(where) +
            "&outFields=OBJECTID,ID&returnGeometry=false&f=json&token=" + encodeURIComponent(tokenMgr.currentToken)

        let xhr = new XMLHttpRequest()
        xhr.open("GET", url)
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return
            try {
                let data = JSON.parse(xhr.responseText)
                if (data.error) { onError("[" + data.error.code + "] " + data.error.message); return }
                let result = {}
                let features = data.features || []
                for (let f of features) {
                    let attrs = f.attributes || {}
                    if (attrs.ID !== undefined && attrs.OBJECTID !== undefined) {
                        result[String(attrs.ID)] = attrs.OBJECTID
                    }
                }
                onDone(result)
            } catch(e) { onError("Parse error: " + e) }
        }
        xhr.send()
    }

    function _doAdd(idx, arcgisId, payload) {
        let edits = [{id: arcgisId, adds: [payload], updates: null, deletes: null}]
        _applyEdits(edits,
            function() { _markDone(idx); _submitNext() },
            function(err) { _markError(idx, err); _submitNext() }
        )
    }

    function _doUpdate(idx, arcgisId, payload) {
        let edits = [{id: arcgisId, adds: null, updates: [payload], deletes: null}]
        _applyEdits(edits,
            function() { _markDone(idx); _submitNext() },
            function(err) { _markError(idx, err); _submitNext() }
        )
    }

    function _doDelete(idx, arcgisId, objectid) {
        let edits = [{id: arcgisId, adds: null, updates: null, deletes: [objectid]}]
        _applyEdits(edits,
            function() { _markDone(idx); _submitNext() },
            function(err) { _markError(idx, err); _submitNext() }
        )
    }

    function _applyEdits(edits, onSuccess, onError) {
        let url = cfg.serviceUrl.replace(/\/$/, "") + "/applyEdits"
        let editsJson = JSON.stringify(edits)
        let body = "f=json&token=" + encodeURIComponent(tokenMgr.currentToken) +
            "&rollbackOnFailure=true&useGlobalIds=false&async=false" +
            "&edits=" + encodeURIComponent(editsJson)

        let xhr = new XMLHttpRequest()
        xhr.open("POST", url)
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return
            try {
                let result = JSON.parse(xhr.responseText)
                if (result.error) { onError("[" + result.error.code + "] " + result.error.message); return }

                let errors = []
                let arr = Array.isArray(result) ? result : [result]
                for (let lr of arr) {
                    for (let item of (lr.addResults || [])) {
                        if (!item.success) errors.push("add error: " + JSON.stringify(item.error))
                    }
                    for (let item of (lr.updateResults || [])) {
                        if (!item.success) errors.push("update error: " + JSON.stringify(item.error))
                    }
                    for (let item of (lr.deleteResults || [])) {
                        if (!item.success) errors.push("delete error: " + JSON.stringify(item.error))
                    }
                }
                if (errors.length > 0) { onError(errors.join("; ")); return }
                onSuccess()
            } catch(e) { onError("Parse error: " + e) }
        }
        xhr.send(body)
    }

    // -------------------------------------------------------------------------
    // Log status helpers
    // -------------------------------------------------------------------------

    function _markDone(idx) {
        let entry = actionLog[idx]
        if (entry.action === "insert") {
            submittedIds[entry.arcgisId + "_" + entry.featureId] = true
            let newIds = submittedIds
            submittedIds = newIds
        }
        let newLog = actionLog.map((e, i) => i === idx ? Object.assign({}, e, {status: "done", error: ""}) : e)
        actionLog = newLog
        _updateBadge()
    }

    function _markError(idx, msg) {
        let newLog = actionLog.map((e, i) => i === idx ? Object.assign({}, e, {status: "error", error: msg}) : e)
        actionLog = newLog
        isSubmitting = false
        _updateBadge()
        _log("ERROR #" + actionLog[idx].seq + ": " + msg)
    }

    function _maybeAutoSubmit() {
        if (cfg.autoSubmit && !isSubmitting && cfg.serviceUrl
                && (tokenMgr.currentToken !== "" || cfg.manualToken !== "")) {
            _doSubmit()
        }
    }

    // -------------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------------

    function _log(msg) {
        console.log("[ArcGISSync] " + msg)
    }
}
